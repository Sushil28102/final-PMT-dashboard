export const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: 'grid', path: '/' },
  { id: 'projects', label: 'Projects', icon: 'layers', path: '/projects' },
  { id: 'team', label: 'Team', icon: 'users', path: '/team' },
  { id: 'tasks', label: 'Tasks', icon: 'check', path: '/tasks' },
  { id: 'meetings', label: 'Meetings', icon: 'video', path: '/meetings' },
  { id: 'invoices', label: 'Invoices', icon: 'receipt', path: '/invoices' },
  { id: 'reports', label: 'Reports', icon: 'chart', path: '/reports' },
  { id: 'settings', label: 'Settings', icon: 'gear', path: '/settings' },
];

export const ranges = ['Today', 'This Week', 'This Month', 'Reports'];
