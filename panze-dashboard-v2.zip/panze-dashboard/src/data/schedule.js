export const schedule = [
  { day: 'Today', items: [
    { id: 1, title: 'App Project', time: '6:45 PM', where: 'Meet', people: 'JS, JM, LB', duration: 45, organizer: 'JS', agenda: 'Review checkout prototype and blockers' },
    { id: 2, title: 'User Research', time: '7:30 PM', where: 'Zoom', people: 'AP, MC', duration: 30, organizer: 'MC', agenda: 'Synthesize interview findings' },
  ] },
  { day: 'Tomorrow', items: [
    { id: 3, title: 'Design Review', time: '11:00 AM', where: 'Meet', people: 'JS, JM', duration: 60, organizer: 'JM', agenda: 'Landing hero and brand refresh' },
    { id: 4, title: 'Sprint Planning', time: '2:00 PM', where: 'Zoom', people: 'Everyone', duration: 90, organizer: 'JS', agenda: 'Scope next two weeks, assign owners' },
  ] },
  { day: 'This Week', items: [
    { id: 5, title: 'Client Demo', time: 'Thu · 4:00 PM', where: 'Meet', people: 'JS, CM', duration: 45, organizer: 'JS', agenda: 'Walk BrightBridge through the build' },
  ] },
];
