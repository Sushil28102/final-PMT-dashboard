export const invoiceStatuses = ['All', 'Overdue', 'Not Paid', 'Partially Paid', 'Fully Paid', 'Draft'];
export const invoices = [
  { id: 'INV-1042', client: 'BrightBridge', amount: 'USD 4,200', due: 'Oct 05', status: 'Overdue' },
  { id: 'INV-1043', client: '9TDesign', amount: 'USD 2,850', due: 'Oct 12', status: 'Not Paid' },
  { id: 'INV-1044', client: 'Northwind', amount: 'USD 6,100', due: 'Oct 15', status: 'Partially Paid' },
  { id: 'INV-1045', client: 'Leafline', amount: 'USD 1,980', due: 'Sep 28', status: 'Fully Paid' },
  { id: 'INV-1046', client: 'Orbit Labs', amount: 'USD 3,400', due: 'Nov 02', status: 'Draft' },
  { id: 'INV-1047', client: 'BrightBridge', amount: 'USD 5,250', due: 'Nov 10', status: 'Not Paid' },
  { id: 'INV-1048', client: 'Leafline', amount: 'USD 2,000', due: 'Sep 15', status: 'Fully Paid' },
];
invoices.push(
  { id: 'INV-1049', client: 'Northwind', amount: 'USD 7,300', due: 'Nov 15', status: 'Not Paid' },
  { id: 'INV-1050', client: 'Orbit Labs', amount: 'USD 4,750', due: 'Sep 30', status: 'Overdue' },
  { id: 'INV-1051', client: '9TDesign', amount: 'USD 3,150', due: 'Sep 10', status: 'Fully Paid' },
  { id: 'INV-1052', client: 'Leafline', amount: 'USD 2,400', due: 'Nov 22', status: 'Draft' },
  { id: 'INV-1053', client: 'BrightBridge', amount: 'USD 8,900', due: 'Oct 20', status: 'Partially Paid' },
  { id: 'INV-1054', client: 'Northwind', amount: 'USD 1,650', due: 'Aug 28', status: 'Fully Paid' },
);
