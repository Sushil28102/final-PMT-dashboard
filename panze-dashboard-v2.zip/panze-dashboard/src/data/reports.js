export const revenue = [
  { month: 'Jan', value: 42 }, { month: 'Feb', value: 55 }, { month: 'Mar', value: 48 }, { month: 'Apr', value: 63 },
  { month: 'May', value: 58 }, { month: 'Jun', value: 71 }, { month: 'Jul', value: 66 }, { month: 'Aug', value: 78 },
  { month: 'Sep', value: 74 }, { month: 'Oct', value: 85 }, { month: 'Nov', value: 80 }, { month: 'Dec', value: 92 },
];
export const expense = [22, 28, 25, 33, 30, 38, 34, 41, 37, 44, 40, 47];
export const breakdown = [
  { label: 'Design', pct: 38, color: '#ee7a3f' },
  { label: 'Development', pct: 44, color: '#2f80ed' },
  { label: 'Research', pct: 18, color: '#8a1fcf' },
];
