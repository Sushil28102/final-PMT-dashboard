export const members = [
  { id: 1, name: 'John Smith', role: 'Project Manager', initials: 'JS', bg: '#fbd9c6', tasks: 12, projects: 5, email: 'john@panze.com', status: 'Online', load: 82, onTime: 96, done: 142, joined: 'Jan 2023', skills: ['Planning', 'Scrum', 'Clients'] },
  { id: 2, name: 'Jacob Martinez', role: 'UI Designer', initials: 'JM', bg: '#f6dcf3', tasks: 9, projects: 3, email: 'jacob@panze.com', status: 'Online', load: 68, onTime: 91, done: 118, joined: 'Mar 2023', skills: ['Figma', 'Branding', 'Motion'] },
  { id: 3, name: 'Luke Bell', role: 'Frontend Developer', initials: 'LB', bg: '#d5f1e2', tasks: 14, projects: 4, email: 'luke@panze.com', status: 'Away', load: 94, onTime: 88, done: 167, joined: 'Feb 2023', skills: ['React', 'CSS', 'Vite'] },
  { id: 4, name: 'Connor Mitchel', role: 'Backend Developer', initials: 'CM', bg: '#fbe0cf', tasks: 8, projects: 2, email: 'connor@panze.com', status: 'Online', load: 55, onTime: 97, done: 131, joined: 'Jun 2023', skills: ['Node', 'SQL', 'APIs'] },
  { id: 5, name: 'Aria Patel', role: 'QA Engineer', initials: 'AP', bg: '#dbe8fb', tasks: 11, projects: 4, email: 'aria@panze.com', status: 'Offline', load: 73, onTime: 93, done: 124, joined: 'Sep 2023', skills: ['Testing', 'Cypress', 'Docs'] },
  { id: 6, name: 'Mia Chen', role: 'Product Researcher', initials: 'MC', bg: '#ece3fb', tasks: 6, projects: 2, email: 'mia@panze.com', status: 'Away', load: 42, onTime: 99, done: 76, joined: 'Nov 2023', skills: ['Interviews', 'Surveys', 'Insights'] },
];
