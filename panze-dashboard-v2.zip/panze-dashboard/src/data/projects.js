export const projects = [
  { id: 1, name: 'BrightBridge Website', client: 'BrightBridge', progress: 72, status: 'In Progress', due: 'Oct 12', tone: 'peach', createdBy: 'JS', created: 'Aug 02', owner: 'JM', team: ['JM', 'LB', 'AP'], tasks: [18, 25], budget: 12000, spent: 7900 },
  { id: 2, name: '9TDesign Mobile App', client: '9TDesign', progress: 45, status: 'In Progress', due: 'Nov 03', tone: 'lilac', createdBy: 'JS', created: 'Aug 19', owner: 'LB', team: ['LB', 'CM', 'MC'], tasks: [11, 24], budget: 18000, spent: 8100 },
  { id: 3, name: 'GitHub Dev Portal', client: 'Internal', progress: 100, status: 'Completed', due: 'Sep 20', tone: 'mint', createdBy: 'CM', created: 'Jun 11', owner: 'CM', completedBy: 'LB', completed: 'Sep 18', team: ['CM', 'LB'], tasks: [30, 30], budget: 9000, spent: 8650 },
  { id: 4, name: 'User Research Study', client: 'Northwind', progress: 18, status: 'Not Started', due: 'Dec 01', tone: 'sky', createdBy: 'MC', created: 'Sep 24', owner: 'MC', team: ['MC', 'AP'], tasks: [2, 12], budget: 6000, spent: 700 },
  { id: 5, name: 'Brand Refresh', client: 'Leafline', progress: 60, status: 'In Progress', due: 'Oct 28', tone: 'peach', createdBy: 'JS', created: 'Sep 01', owner: 'JM', team: ['JM', 'MC'], tasks: [9, 15], budget: 7500, spent: 4300 },
  { id: 6, name: 'Analytics Revamp', client: 'Orbit Labs', progress: 100, status: 'Completed', due: 'Aug 30', tone: 'mint', createdBy: 'JS', created: 'May 20', owner: 'AP', completedBy: 'AP', completed: 'Aug 27', team: ['AP', 'CM', 'LB'], tasks: [22, 22], budget: 14000, spent: 13100 },
];
