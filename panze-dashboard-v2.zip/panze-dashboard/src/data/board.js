export const columns = ['To Do', 'In Progress', 'Done'];
export const boardTasks = [
  { id: 1, title: 'Design landing hero', owner: 'JM', tone: 'peach', column: 0, priority: 'High', due: 'Oct 03', project: 'BrightBridge', sub: [1, 4], comments: 5 },
  { id: 2, title: 'Set up CI pipeline', owner: 'LB', tone: 'sky', column: 0, priority: 'Medium', due: 'Oct 08', project: 'Dev Portal', sub: [0, 3], comments: 2 },
  { id: 3, title: 'Prototype checkout flow', owner: 'JM', tone: 'lilac', column: 1, priority: 'High', due: 'Oct 01', project: '9TDesign', sub: [3, 5], comments: 9 },
  { id: 4, title: 'API rate limiting', owner: 'CM', tone: 'sky', column: 1, priority: 'Medium', due: 'Oct 10', project: '9TDesign', sub: [2, 4], comments: 3 },
  { id: 5, title: 'Write test plan', owner: 'AP', tone: 'mint', column: 1, priority: 'Low', due: 'Oct 14', project: 'Analytics', sub: [1, 2], comments: 1 },
  { id: 6, title: 'Upload dev files', owner: 'LB', tone: 'mint', column: 2, priority: 'Low', due: 'Sep 25', project: 'Dev Portal', sub: [3, 3], comments: 4 },
  { id: 7, title: 'Client kickoff notes', owner: 'JS', tone: 'peach', column: 2, priority: 'Medium', due: 'Sep 22', project: 'Northwind', sub: [2, 2], comments: 6 },
];
