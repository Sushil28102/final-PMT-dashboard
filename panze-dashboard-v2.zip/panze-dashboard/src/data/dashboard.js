export const tasks = [
  { id: 1, title: 'BrightBridge — Website Design', desc: 'Design a modern website with', time: 'Today · 2:30 PM', tone: 'peach', color: '#ee7a3f' },
  { id: 2, title: 'GitHub — Upload Dev Files', desc: 'Collaborate with developers to', time: 'Today · 4:00 PM', tone: 'sky', color: '#25405c' },
  { id: 3, title: '9TDesign — Mobile App', desc: 'Ready prototype for testing', time: 'Tomorrow · 11:00 AM', tone: 'lilac', color: '#a04fd6' },
];
export const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const meetings = [
  { id: 1, title: 'App Project', time: '6:45 PM', where: 'Meet' },
  { id: 2, title: 'User Research', time: '6:45 PM', where: 'Zoom' },
];
export const tickets = [
  { id: 1, name: 'Jacob Martinez', initials: 'JM', bg: '#f6dcf3' },
  { id: 2, name: 'Luke Bell', initials: 'LB', bg: '#d5f1e2' },
  { id: 3, name: 'Connor Mitchel', initials: 'CM', bg: '#fbe0cf' },
];
export const invoiceSummary = [
  { label: 'Overdue', pct: 47, color: '#8a1fcf' },
  { label: 'Not Paid', pct: 47, color: '#ef4f5f' },
  { label: 'Partially Paid', pct: 47, color: '#2fa8e8' },
  { label: 'Fully Paid', pct: 47, color: '#27ae60' },
  { label: 'Draft', pct: 16, color: '#f2b632' },
];
export const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'];
export const income = [30, 55, 42, 60, 35, 58, 48, 62, 40, 52, 66, 45, 58, 50];
export const expense = [12, 20, 14, 26, 16, 18, 12, 24, 14, 16, 10, 22, 18, 14];

export const waveSets = {
  '7D': { labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], a: [3.2, 4.1, 3.8, 5.4, 4.9, 6.2, 5.6], b: [1.8, 2.2, 2.6, 2.1, 3, 2.4, 2.9] },
  '30D': { labels: ['1', '4', '7', '10', '13', '16', '19', '22', '25', '28'], a: [8, 11, 9.5, 14, 12, 16.5, 15, 19, 17.5, 22], b: [4, 5.5, 5, 6.5, 6, 7.5, 7, 8.5, 8, 9] },
  '12M': { labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], a: [22, 31, 27, 38, 34, 46, 41, 52, 48, 60, 55, 68], b: [12, 15, 14, 19, 17, 21, 20, 24, 22, 27, 25, 29] },
};
