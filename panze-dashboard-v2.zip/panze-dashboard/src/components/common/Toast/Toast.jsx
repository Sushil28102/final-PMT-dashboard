import '../../../styles/components/common/Toast.css';

export default function Toast({ message }) {
  return <div className={`toast ${message ? 'is-visible' : ''}`} role="status">{message}</div>;
}
