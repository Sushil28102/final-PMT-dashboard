import '../../../styles/components/common/Leaves.css';

const Leaf = ({ fill, vein }) => (
  <>
    <path d="M10 190C10 90 70 20 190 10 190 110 130 180 10 190z" fill={fill} />
    <path d="M10 190C60 130 110 80 190 10" stroke={vein} strokeWidth="3" fill="none" strokeLinecap="round" />
  </>
);

export default function Leaves() {
  return (
    <div className="leaves" aria-hidden="true">
      <svg className="leaf leaf--a" viewBox="0 0 200 200"><Leaf fill="#cfe9d9" vein="#a9d3ba" /></svg>
      <svg className="leaf leaf--b" viewBox="0 0 200 200"><Leaf fill="#f9d9c6" vein="#f0bfa3" /></svg>
      <svg className="leaf leaf--c" viewBox="0 0 200 200"><Leaf fill="#e5d5f5" vein="#cfb6ea" /></svg>
      <svg className="leaf leaf--d" viewBox="0 0 200 200"><Leaf fill="#d7ecf8" vein="#b3d7ee" /></svg>
      <svg className="sprig" viewBox="0 0 120 240" fill="none" stroke="#b7dcc5" strokeWidth="3" strokeLinecap="round">
        <path d="M60 235C60 160 62 90 60 10" />
        <path d="M60 190c-25-6-38-22-40-40 24 2 38 16 40 40zM60 150c25-6 38-22 40-40-24 2-38 16-40 40zM60 110c-25-6-38-22-40-40 24 2 38 16 40 40zM60 70c25-6 38-22 40-40-24 2-38 16-40 40z" fill="#d3ecdd" />
      </svg>
    </div>
  );
}
