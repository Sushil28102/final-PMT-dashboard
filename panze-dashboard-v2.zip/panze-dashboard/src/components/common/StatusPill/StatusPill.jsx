import '../../../styles/components/common/StatusPill.css';

const tones = {
  Overdue: 'purple',
  'Not Paid': 'red',
  'Partially Paid': 'cyan',
  'Fully Paid': 'green',
  Draft: 'yellow',
  'In Progress': 'orange',
  Completed: 'green',
  'Not Started': 'grey',
};

export default function StatusPill({ status }) {
  return <span className={`pill pill--${tones[status] || 'grey'}`}>{status}</span>;
}
