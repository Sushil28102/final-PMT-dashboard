import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../Icon/Icon.jsx';
import { useApp } from '../../../store/AppContext.jsx';
import { navItems } from '../../../data/navigation.js';
import '../../../styles/components/common/CommandPalette.css';

export default function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [i, setI] = useState(0);
  const go = useNavigate();
  const { state, toggleTheme, reset } = useApp();

  useEffect(() => {
    const key = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setQ(''); setI(0); setOpen((o) => !o); }
      if (e.key === 'Escape') setOpen(false);
    };
    const show = () => { setQ(''); setI(0); setOpen(true); };
    window.addEventListener('keydown', key);
    window.addEventListener('open-palette', show);
    return () => { window.removeEventListener('keydown', key); window.removeEventListener('open-palette', show); };
  }, []);

  const items = useMemo(() => {
    const jump = (p) => () => go(p);
    const all = [
      ...navItems.map((n) => ({ label: `Go to ${n.label}`, hint: 'Navigate', icon: n.icon, run: jump(n.path) })),
      { label: 'Toggle dark mode', hint: 'Action', icon: 'moon', run: toggleTheme },
      { label: 'Restore demo data', hint: 'Action', icon: 'gear', run: reset },
      ...state.tasks.map((t) => ({ label: t.title, hint: 'Task', icon: 'check', run: jump('/tasks') })),
      ...state.projects.map((p) => ({ label: p.name, hint: 'Project', icon: 'layers', run: jump('/projects') })),
      ...state.invoices.map((v) => ({ label: `Invoice · ${v.client}`, hint: v.status, icon: 'receipt', run: jump('/invoices') })),
    ];
    return all.filter((x) => x.label.toLowerCase().includes(q.toLowerCase())).slice(0, 8);
  }, [q, state, go, toggleTheme, reset]);

  if (!open) return null;
  const run = (x) => { setOpen(false); x?.run(); };
  const onKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setI((n) => Math.min(items.length - 1, n + 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setI((n) => Math.max(0, n - 1)); }
    if (e.key === 'Enter') run(items[i]);
  };
  return (
    <div className="palette-backdrop" onClick={() => setOpen(false)}>
      <div className="palette" onClick={(e) => e.stopPropagation()}>
        <div className="palette__input"><Icon name="search" size={18} /><input autoFocus placeholder="Search tasks, projects, invoices or run a command" value={q} onChange={(e) => { setQ(e.target.value); setI(0); }} onKeyDown={onKey} /></div>
        <ul>
          {items.map((x, n) => (
            <li key={x.label + n} className={n === i ? 'is-active' : ''} onMouseEnter={() => setI(n)} onClick={() => run(x)}>
              <Icon name={x.icon} size={17} /><span>{x.label}</span><small>{x.hint}</small>
            </li>
          ))}
          {!items.length && <li className="palette__empty">No results</li>}
        </ul>
      </div>
    </div>
  );
}
