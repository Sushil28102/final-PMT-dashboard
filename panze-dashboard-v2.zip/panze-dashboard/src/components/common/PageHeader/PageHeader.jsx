import Icon from '../Icon/Icon.jsx';
import '../../../styles/components/common/PageHeader.css';

export default function PageHeader({ eyebrow, title, actionLabel, onAction, children }) {
  return (
    <div className="page-header">
      <div>
        {eyebrow && <p className="page-header__eyebrow">{eyebrow}</p>}
        <h1 className="page-header__title">{title}</h1>
      </div>
      <div className="page-header__side">
        {children}
        {actionLabel && (
          <button className="page-header__btn" onClick={onAction}>
            <Icon name="plus" size={16} />
            {actionLabel}
          </button>
        )}
      </div>
    </div>
  );
}
