import Icon from '../Icon/Icon.jsx';
import '../../../styles/components/common/Card.css';

export default function Card({ title, action, className = '', children }) {
  return (
    <section className={`card ${className}`}>
      {title && (
        <div className="card__head">
          <h2 className="card__title">{title}</h2>
          {action && (
            <button className="card__action" aria-label={`${title} options`}>
              <Icon name={action} size={16} />
            </button>
          )}
        </div>
      )}
      {children}
    </section>
  );
}
