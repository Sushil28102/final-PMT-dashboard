import { useState } from 'react';
import Icon from '../../common/Icon/Icon.jsx';
import { useApp } from '../../../store/AppContext.jsx';
import { ranges } from '../../../data/navigation.js';
import '../../../styles/components/layout/Topbar.css';

export default function Topbar({ onMenu }) {
  const { state, toggleTheme } = useApp();
  const pct = Math.round((state.tasks.filter((t) => t.column === 2).length / (state.tasks.length || 1)) * 100);
  const [range, setRange] = useState('This Month');
  return (
    <header className="topbar">
      <button className="topbar__menu" onClick={onMenu} aria-label="Open menu"><Icon name="menu" /></button>
      <div className="topbar__tabs">
        {ranges.map((r) => (
          <button key={r} className={`topbar__tab ${range === r ? 'is-active' : ''}`} onClick={() => setRange(r)}>{r}</button>
        ))}
      </div>
      <div className="topbar__right">
        <button className="topbar__search" onClick={() => window.dispatchEvent(new Event('open-palette'))}><Icon name="search" size={15} />Search or jump to<kbd>Ctrl K</kbd></button>
        <div className="topbar__chip" title={`Sprint ${pct}% complete`}><strong>Sprint</strong><span><i style={{ width: `${pct}%` }} /></span><small>{pct}%</small></div>
        <button className="topbar__icon" onClick={toggleTheme} aria-label="Toggle theme"><Icon name={state.theme === 'dark' ? 'sun' : 'moon'} size={18} /></button>
        <button className="topbar__icon" aria-label="Messages"><Icon name="mail" size={18} /></button>
        <button className="topbar__icon" aria-label="Notifications"><Icon name="bell" size={18} /></button>
        <button className="topbar__icon" aria-label="Help"><Icon name="help" size={18} /></button>
        <div className="topbar__user">
          <span className="topbar__avatar">JS</span>
          <div className="topbar__user-text"><strong>John Smith</strong><span>Project manager</span></div>
        </div>
      </div>
    </header>
  );
}
