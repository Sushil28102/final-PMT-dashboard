import { NavLink } from 'react-router-dom';
import Icon from '../../common/Icon/Icon.jsx';
import { navItems } from '../../../data/navigation.js';
import '../../../styles/components/layout/Sidebar.css';

export default function Sidebar({ expanded, onToggle, mobileOpen, onCloseMobile }) {
  return (
    <>
      <div className={`sidebar-backdrop ${mobileOpen ? 'is-visible' : ''}`} onClick={onCloseMobile} />
      <aside className={`sidebar ${expanded ? 'is-expanded' : ''} ${mobileOpen ? 'is-mobile-open' : ''}`}>
        <div className="sidebar__brand">
          <svg width="30" height="30" viewBox="0 0 32 32" fill="none" stroke="#14232b" strokeWidth="2.4" strokeLinejoin="round">
            <path d="M16 3l11 13-11 13L5 16z" />
            <path d="M16 11l5 5-5 5-5-5z" />
          </svg>
          <span className="sidebar__brand-text">panze</span>
        </div>
        <nav className="sidebar__nav">
          {navItems.map((item) => (
            <NavLink
              key={item.id}
              to={item.path}
              end={item.path === '/'}
              title={item.label}
              onClick={onCloseMobile}
              className={({ isActive }) => `sidebar__link ${isActive ? 'is-active' : ''}`}
            >
              <Icon name={item.icon} />
              <span className="sidebar__label">{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <button className="sidebar__toggle" onClick={onToggle} aria-label={expanded ? 'Collapse sidebar' : 'Expand sidebar'} aria-expanded={expanded}>
          <Icon name={expanded ? 'chevronsLeft' : 'chevronsRight'} size={18} />
          <span className="sidebar__label">Collapse</span>
        </button>
      </aside>
    </>
  );
}
