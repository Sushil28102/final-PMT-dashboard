import Card from '../../common/Card/Card.jsx';
import { useApp } from '../../../store/AppContext.jsx';

const W = 300, H = 150, N = 10;
export default function Burndown() {
  const { state } = useApp();
  const total = state.tasks.length, left = state.tasks.filter((t) => t.column < 2).length;
  const ideal = Array.from({ length: N }, (_, i) => total * (1 - i / (N - 1)));
  const actual = ideal.map((v, i) => (i === N - 1 ? left : Math.max(left, v + Math.sin(i * 1.7) * 0.8 * (1 - i / N) + (i / N) * (left - v) * 0.3)));
  const pt = (a) => a.map((v, i) => `${(i / (N - 1)) * W},${H - (v / (total || 1)) * (H - 10) - 4}`).join(' ');
  const gap = Math.round(left - ideal[N - 1] - (ideal[N - 2] - ideal[N - 1]) * 0);
  return (
    <Card title="Sprint burndown" action="chart" className="burn">
      <p className="burn__sum"><strong>{left}</strong> of {total} tasks left <em className={left <= ideal[N - 2] + 1 ? 'is-up' : 'is-down'}>{left <= ideal[N - 2] + 1 ? 'On track' : `${gap} behind plan`}</em></p>
      <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label="Burndown chart">
        <polyline points={pt(ideal)} className="burn__ideal" />
        <polygon points={`0,${H} ${pt(actual)} ${W},${H}`} className="burn__area" />
        <polyline points={pt(actual)} className="burn__actual" />
      </svg>
      <div className="burn__legend"><span><i className="a" />Actual</span><span><i className="i" />Ideal</span></div>
    </Card>
  );
}
