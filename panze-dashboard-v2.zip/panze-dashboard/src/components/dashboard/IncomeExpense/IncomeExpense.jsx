import Card from '../../common/Card/Card.jsx';
import { income, expense, months } from '../../../data/dashboard.js';
import '../../../styles/components/dashboard/IncomeExpense.css';

export default function IncomeExpense() {
  return (
    <Card title="Income VS Expense" action="list">
      <div className="income__legend">
        <span style={{ color: '#2f80ed' }}>● Income: $24,600</span>
        <span style={{ color: '#f5a623' }}>● Expense: $13,290</span>
      </div>
      <div className="income__chart">
        {income.map((v, i) => (
          <div key={i} className="income__col">
            <span className="income__bar income__bar--in" style={{ height: `${v}%` }} />
            <span className="income__bar income__bar--ex" style={{ height: `${expense[i]}%` }} />
          </div>
        ))}
      </div>
      <div className="income__months">{months.map((m) => <span key={m}>{m}</span>)}</div>
    </Card>
  );
}
