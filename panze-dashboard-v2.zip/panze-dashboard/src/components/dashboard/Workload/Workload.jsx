import Card from '../../common/Card/Card.jsx';
import { members } from '../../../data/team.js';

export default function Workload() {
  const list = [...members].sort((a, b) => b.load - a.load);
  return (
    <Card title="Team workload" action="users" className="load">
      <ul>
        {list.map((m) => (
          <li key={m.id}>
            <span className="load__av" style={{ background: m.bg }}>{m.initials}</span>
            <div><div className="load__row"><b>{m.name}</b><small>{m.tasks} tasks · {m.load}%</small></div>
              <div className="load__bar"><i className={m.load > 90 ? 'hot' : m.load > 70 ? 'warm' : ''} style={{ width: `${m.load}%` }} /></div></div>
          </li>
        ))}
      </ul>
      <p className="load__note">{list[0].name.split(' ')[0]} is over capacity — consider reassigning a task.</p>
    </Card>
  );
}
