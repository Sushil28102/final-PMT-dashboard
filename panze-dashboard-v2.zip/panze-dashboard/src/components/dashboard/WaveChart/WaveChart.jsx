import { useState } from 'react';
import Card from '../../common/Card/Card.jsx';
import { waveSets } from '../../../data/dashboard.js';
import '../../../styles/components/dashboard/WaveChart.css';

const W = 700, H = 260, PAD = 24, BASE = H - 24;
const smooth = (p) => p.reduce((d, [x, y], i) => { if (!i) return `M${x},${y}`; const [px, py] = p[i - 1]; const c = (px + x) / 2; return `${d} C${c},${py} ${c},${y} ${x},${y}`; }, '');

export default function WaveChart() {
  const [range, setRange] = useState('12M');
  const [hover, setHover] = useState(null);
  const s = waveSets[range];
  const n = s.a.length;
  const max = Math.max(...s.a, ...s.b) * 1.15;
  const pts = (arr) => arr.map((v, i) => [PAD + i * ((W - PAD * 2) / (n - 1)), BASE - (v / max) * (H - 70)]);
  const A = pts(s.a), B = pts(s.b), F = pts(s.a.map((v, i) => v * 0.55 + s.b[i] * 0.9));
  const la = smooth(A), lb = smooth(B);
  const sum = (arr) => arr.reduce((x, y) => x + y, 0);
  const move = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const i = Math.round((((e.clientX - r.left) / r.width) * W - PAD) / ((W - PAD * 2) / (n - 1)));
    setHover(Math.min(n - 1, Math.max(0, i)));
  };
  const pos = (pt) => ({ left: `${(pt[0] / W) * 100}%`, top: `${(pt[1] / H) * 100}%` });
  return (
    <Card className="wave">
      <div className="wave__head">
        <div>
          <h2>Revenue flow</h2>
          <div className="wave__totals">
            <span><i style={{ background: 'var(--accent)' }} />Income <strong>${sum(s.a).toFixed(0)}k</strong></span>
            <span><i style={{ background: '#f5a623' }} />Expense <strong>${sum(s.b).toFixed(0)}k</strong></span>
            <span className="wave__net">Net +${(sum(s.a) - sum(s.b)).toFixed(0)}k</span>
          </div>
        </div>
        <div className="wave__tabs">
          {Object.keys(waveSets).map((r) => <button key={r} className={range === r ? 'is-active' : ''} onClick={() => { setRange(r); setHover(null); }}>{r}</button>)}
        </div>
      </div>
      <div className="wave__plot" onMouseMove={move} onMouseLeave={() => setHover(null)}>
        <svg key={range} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
          <defs>
            <linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#7a6cf0" stopOpacity=".45" /><stop offset="1" stopColor="#7a6cf0" stopOpacity="0" /></linearGradient>
            <linearGradient id="gb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#f5a623" stopOpacity=".3" /><stop offset="1" stopColor="#f5a623" stopOpacity="0" /></linearGradient>
          </defs>
          {[0.25, 0.5, 0.75].map((g) => <line key={g} x1="0" x2={W} y1={BASE - g * (H - 50)} y2={BASE - g * (H - 50)} className="wave__grid" />)}
          <path d={smooth(F)} className="wave__forecast" />
          <path d={`${lb} L${B[n - 1][0]},${BASE} L${B[0][0]},${BASE}Z`} fill="url(#gb)" className="wave__area" />
          <path d={`${la} L${A[n - 1][0]},${BASE} L${A[0][0]},${BASE}Z`} fill="url(#ga)" className="wave__area" />
          <path d={lb} className="wave__line wave__line--b" pathLength="1" />
          <path d={la} className="wave__line wave__line--a" pathLength="1" />
        </svg>
        {hover !== null && (
          <>
            <div className="wave__cursor" style={{ left: pos(A[hover]).left }} />
            <span className="wave__dot" style={{ ...pos(A[hover]), borderColor: '#7a6cf0' }} />
            <span className="wave__dot" style={{ ...pos(B[hover]), borderColor: '#f5a623' }} />
            <div className="wave__tip" style={{ left: pos(A[hover]).left }}>
              <small>{s.labels[hover]}</small>
              <b>${s.a[hover]}k income</b>
              <em>${s.b[hover]}k expense</em>
            </div>
          </>
        )}
      </div>
      <div className="wave__labels">{s.labels.map((l) => <span key={l}>{l}</span>)}</div>
    </Card>
  );
}
