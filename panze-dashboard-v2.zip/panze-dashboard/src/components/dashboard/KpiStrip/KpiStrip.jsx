import { Link } from 'react-router-dom';
import Icon from '../../common/Icon/Icon.jsx';
import { useApp } from '../../../store/AppContext.jsx';
import '../../../styles/components/dashboard/KpiStrip.css';

export default function KpiStrip() {
  const { state } = useApp();
  const open = state.tasks.filter((t) => t.column < 2).length;
  const active = state.projects.filter((p) => p.status === 'In Progress').length;
  const due = state.invoices.filter((i) => ['Overdue', 'Not Paid', 'Partially Paid'].includes(i.status)).reduce((a, i) => a + i.amount, 0);
  const today = state.meetings.filter((m) => m.day === 'Today').length;
  const items = [
    { label: 'Open tasks', value: open, icon: 'check', to: '/tasks', tone: 'lilac' },
    { label: 'Active projects', value: active, icon: 'layers', to: '/projects', tone: 'sky' },
    { label: 'Outstanding', value: `$${due.toLocaleString()}`, icon: 'receipt', to: '/invoices', tone: 'peach' },
    { label: 'Meetings today', value: today, icon: 'video', to: '/meetings', tone: 'mint' },
  ];
  return (
    <div className="kpis">
      {items.map((k) => (
        <Link key={k.label} to={k.to} className="kpi">
          <span className={`kpi__icon kpi__icon--${k.tone}`}><Icon name={k.icon} size={18} /></span>
          <div><small>{k.label}</small><strong>{k.value}</strong></div>
        </Link>
      ))}
    </div>
  );
}
