import Card from '../../common/Card/Card.jsx';
import ProgressBar from '../../common/ProgressBar/ProgressBar.jsx';
import { useApp } from '../../../store/AppContext.jsx';
import '../../../styles/components/dashboard/InvoiceOverview.css';

const colors = { Overdue: '#8a1fcf', 'Not Paid': '#ef4f5f', 'Partially Paid': '#2fa8e8', 'Fully Paid': '#27ae60', Draft: '#f2b632' };

export default function InvoiceOverview() {
  const { state } = useApp();
  const all = state.invoices.length || 1;
  return (
    <Card title="Invoice Overview" action="list">
      <ul className="invoice__list">
        {Object.keys(colors).map((label) => {
          const list = state.invoices.filter((i) => i.status === label);
          const total = list.reduce((a, i) => a + i.amount, 0);
          return (
            <li key={label}>
              <div className="invoice__row">
                <span>{label}</span>
                <span className="invoice__meta">{list.length}<i />USD {total.toLocaleString()}</span>
              </div>
              <ProgressBar value={(list.length / all) * 100} color={colors[label]} />
            </li>
          );
        })}
      </ul>
    </Card>
  );
}
