import { Link } from 'react-router-dom';
import Card from '../../common/Card/Card.jsx';
import Icon from '../../common/Icon/Icon.jsx';
import { useApp } from '../../../store/AppContext.jsx';
import '../../../styles/components/dashboard/Meetings.css';

export default function Meetings() {
  const { state } = useApp();
  const list = state.meetings.filter((m) => m.day === 'Today').slice(0, 2);
  return (
    <Card title="My Meetings" action="cal">
      <ul className="meetings__list">
        {list.map((m) => (
          <li key={m.id} className="meeting">
            <div><small>Today</small><strong>{m.time}</strong></div>
            <div><strong>{m.title}</strong><small>{m.where}</small></div>
            <Icon name="arrow" size={14} className="meeting__arrow" />
          </li>
        ))}
        {!list.length && <li className="meeting"><small>Nothing scheduled today</small></li>}
      </ul>
      <Link to="/meetings" className="meetings__all">See All Meetings <Icon name="chevronRight" size={14} /></Link>
    </Card>
  );
}
