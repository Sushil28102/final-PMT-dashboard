import { useState } from 'react';
import Card from '../../common/Card/Card.jsx';
import Icon from '../../common/Icon/Icon.jsx';
import { tasks, weekDays } from '../../../data/dashboard.js';
import '../../../styles/components/dashboard/TaskList.css';

export default function TaskList() {
  const [tab, setTab] = useState('Today');
  const [day, setDay] = useState(4);
  const visible = tasks.filter((t) => t.time.startsWith(tab));
  return (
    <Card title="My Tasks" action="plus">
      <div className="tasks__tabs">
        {['Today', 'Tomorrow'].map((t) => (
          <button key={t} className={`tasks__tab ${tab === t ? 'is-active' : ''}`} onClick={() => setTab(t)}>{t}</button>
        ))}
      </div>
      <button className="tasks__filter">
        <span className="tasks__count">12</span>
        <span>On Going Tasks</span>
        <Icon name="chevronDown" size={16} />
      </button>
      <ul className="tasks__list">
        {visible.map((t) => (
          <li key={t.id} className={`task task--${t.tone}`}>
            <div className="task__top">
              <span className="task__badge" style={{ background: t.color }}>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="#fff"><path d="M6 0l6 6-6 6-6-6z" /></svg>
              </span>
              <Icon name="tick" size={14} className="task__tick" />
            </div>
            <h3>{t.title}</h3>
            <p>{t.desc}</p>
            <span className="task__time">{t.time}</span>
          </li>
        ))}
        {!visible.length && <li className="tasks__empty">No tasks for {tab.toLowerCase()}.</li>}
      </ul>
      <div className="schedule">
        <div className="schedule__head"><strong>Task Schedule</strong><span>August 2026</span></div>
        <div className="schedule__row">
          {weekDays.map((d, i) => (
            <button key={d} className={`schedule__day ${day === i ? 'is-active' : ''}`} onClick={() => setDay(i)}>
              <small>{d}</small>
              <span>{i + 1}</span>
            </button>
          ))}
        </div>
      </div>
    </Card>
  );
}
