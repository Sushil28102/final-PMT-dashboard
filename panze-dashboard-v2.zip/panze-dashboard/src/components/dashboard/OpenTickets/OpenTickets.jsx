import Card from '../../common/Card/Card.jsx';
import Icon from '../../common/Icon/Icon.jsx';
import { tickets } from '../../../data/dashboard.js';
import '../../../styles/components/dashboard/OpenTickets.css';

export default function OpenTickets() {
  return (
    <Card title="Open Tickets" action="list">
      <ul className="tickets__list">
        {tickets.map((t) => (
          <li key={t.id} className="ticket">
            <span className="ticket__avatar" style={{ background: t.bg }}>{t.initials}</span>
            <div>
              <strong>{t.name}</strong>
              <p>I need 3 more new features on the mobile app design.</p>
              <button className="ticket__btn">Check <Icon name="chevronRight" size={12} /></button>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  );
}
