import Card from '../../common/Card/Card.jsx';
import '../../../styles/components/dashboard/ProjectsOverview.css';

const RADIUS = 52;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export default function ProjectsOverview({ percent = 75 }) {
  return (
    <Card title="Projects Overview" action="arrow">
      <div className="projects__donut">
        <svg viewBox="0 0 130 130" role="img" aria-label={`${percent}% project complete`}>
          <circle cx="65" cy="65" r={RADIUS} fill="none" stroke="#dbe6f5" strokeWidth="12" />
          <circle cx="65" cy="65" r={RADIUS} fill="none" stroke="#2f80ed" strokeWidth="12" strokeLinecap="round" strokeDasharray={`${(CIRCUMFERENCE * percent) / 100} ${CIRCUMFERENCE}`} transform="rotate(-90 65 65)" />
        </svg>
        <div className="projects__center"><strong>{percent}%</strong><span>Project Complete</span></div>
      </div>
      <ul className="projects__legend">
        <li><i style={{ background: '#f5a623' }} /><span style={{ color: '#f5a623' }}>In Progress 14</span></li>
        <li><i style={{ background: '#2f80ed' }} /><span style={{ color: '#2f80ed' }}>Completed 32</span></li>
        <li><i style={{ background: '#6b7a83' }} /><span>Not Started 54</span></li>
      </ul>
    </Card>
  );
}
