import { useState } from 'react';
import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import Card from '../../components/common/Card/Card.jsx';
import Icon from '../../components/common/Icon/Icon.jsx';
import ProgressBar from '../../components/common/ProgressBar/ProgressBar.jsx';
import { useApp } from '../../store/AppContext.jsx';
import { revenue, expense, breakdown } from '../../data/reports.js';
import { download } from '../../utils/download.js';
import '../../styles/pages/Reports.css';

const sum = (a) => a.reduce((x, y) => x + y, 0);
const R = 46, C = 2 * Math.PI * R;
function Donut({ parts, center, sub }) {
  const t = sum(parts.map((p) => p.value)) || 1; let off = 0;
  return (
    <div className="donut">
      <svg viewBox="0 0 120 120"><circle cx="60" cy="60" r={R} fill="none" stroke="var(--line)" strokeWidth="14" />
        {parts.map((p) => { const len = (p.value / t) * C, el = <circle key={p.label} cx="60" cy="60" r={R} fill="none" stroke={p.color} strokeWidth="14" strokeDasharray={`${len} ${C}`} strokeDashoffset={-off} transform="rotate(-90 60 60)" />; off += len; return el; })}</svg>
      <div><strong>{center}</strong><small>{sub}</small></div>
    </div>
  );
}

export default function Reports() {
  const { state } = useApp();
  const [range, setRange] = useState(12);
  const rev = revenue.slice(-range), exp = expense.slice(-range);
  const R$ = sum(rev.map((r) => r.value)), E$ = sum(exp), net = R$ - E$, margin = Math.round((net / R$) * 100);
  const best = rev.reduce((a, r) => (r.value > a.value ? r : a));
  const clients = Object.entries(state.invoices.reduce((m, i) => ({ ...m, [i.client]: (m[i.client] || 0) + i.amount }), {})).sort((a, b) => b[1] - a[1]);
  const overdue = state.invoices.filter((i) => i.status === 'Overdue').reduce((a, i) => a + i.amount, 0);
  const ps = ['Completed', 'In Progress', 'Not Started'].map((s, i) => ({ label: s, value: state.projects.filter((p) => p.status === s).length, color: ['#27ae60', '#f5a623', '#8c99a0'][i] }));
  const W = 700, H = 240, step = W / rev.length, y = (v) => H - 24 - (v / 100) * (H - 40);
  const line = exp.map((v, i) => `${i ? 'L' : 'M'}${i * step + step / 2},${y(v)}`).join(' ');
  const rows = rev.map((r, i) => [r.month, r.value * 1000, exp[i] * 1000, (r.value - exp[i]) * 1000]);
  const stats = [['Revenue', `$${R$}k`, `Best: ${best.month}`, true], ['Expenses', `$${E$}k`, `${Math.round((E$ / R$) * 100)}% of revenue`, false], ['Net profit', `$${net}k`, 'After expenses', net > 0], ['Margin', `${margin}%`, margin > 45 ? 'Healthy' : 'Watch costs', margin > 45]];
  const insights = [`${best.month} was the strongest month at $${best.value}k.`, `${clients[0][0]} is the top client with $${clients[0][1].toLocaleString()} billed.`, overdue ? `$${overdue.toLocaleString()} is overdue and needs a follow-up.` : 'No overdue invoices.', `Profit margin is ${margin}% over the last ${range} months.`];
  return (
    <div>
      <PageHeader eyebrow="Performance at a glance" title="Reports">
        <div className="wave__tabs">{[6, 12].map((n) => <button key={n} className={range === n ? 'is-active' : ''} onClick={() => setRange(n)}>{n} months</button>)}</div>
        <button className="btn-ghost" onClick={() => download('panze-report.csv', ['Month,Revenue,Expenses,Net', ...rows.map((r) => r.join(','))].join('\n'))}>Export CSV</button>
        <button className="btn-ghost" onClick={() => download('panze-report.json', JSON.stringify({ range, revenue: rev, expense: exp, clients, projects: ps }, null, 2), 'application/json')}>Export JSON</button>
        <button className="btn-primary" onClick={() => window.print()}>Print / PDF</button>
      </PageHeader>
      <div className="reports__stats">
        {stats.map(([l, v, n, up]) => <Card key={l} className="stat"><span>{l}</span><strong>{v}</strong><em className={up ? 'is-up' : 'is-down'}><Icon name={up ? 'up' : 'down'} size={14} />{n}</em></Card>)}
      </div>
      <div className="reports__row">
        <Card title="Revenue vs expenses">
          <div className="rp-legend"><span><i style={{ background: '#5b4bdb' }} />Revenue</span><span><i style={{ background: '#f5a623' }} />Expenses</span></div>
          <svg className="rp-combo" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label="Revenue bars with expense line">
            {[25, 50, 75].map((g) => <line key={g} x1="0" x2={W} y1={y(g)} y2={y(g)} className="wave__grid" />)}
            {rev.map((r, i) => <g key={r.month}><rect x={i * step + step * 0.2} width={step * 0.6} y={y(r.value)} height={H - 24 - y(r.value)} rx="8" fill="#5b4bdb" opacity={r.month === best.month ? 1 : 0.55}><title>{`${r.month}: $${r.value}k revenue`}</title></rect></g>)}
            <path d={line} fill="none" stroke="#f5a623" strokeWidth="3" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
          </svg>
          <div className="wave__labels">{rev.map((r) => <span key={r.month}>{r.month}</span>)}</div>
        </Card>
        <Card title="Work breakdown">
          <Donut parts={breakdown.map((b) => ({ label: b.label, value: b.pct, color: b.color }))} center="100%" sub="of hours" />
          <ul className="reports__breakdown">{breakdown.map((b) => <li key={b.label}><div><span><i className="sw" style={{ background: b.color }} />{b.label}</span><strong>{b.pct}%</strong></div><ProgressBar value={b.pct} color={b.color} /></li>)}</ul>
        </Card>
      </div>
      <div className="reports__row3">
        <Card title="Top clients by billing"><ul className="rp-clients">{clients.slice(0, 5).map(([c, v]) => <li key={c}><span>{c}</span><ProgressBar value={(v / clients[0][1]) * 100} color="#5b4bdb" /><strong>${v.toLocaleString()}</strong></li>)}</ul></Card>
        <Card title="Project health"><Donut parts={ps} center={state.projects.length} sub="projects" /><ul className="rp-legend rp-legend--col">{ps.map((p) => <li key={p.label}><span><i style={{ background: p.color }} />{p.label}</span><strong>{p.value}</strong></li>)}</ul></Card>
        <Card title="Insights"><ul className="rp-insights">{insights.map((t) => <li key={t}>{t}</li>)}</ul></Card>
      </div>
    </div>
  );
}
