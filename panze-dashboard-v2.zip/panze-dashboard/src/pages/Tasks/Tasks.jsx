import { useState } from 'react';
import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import Icon from '../../components/common/Icon/Icon.jsx';
import ProgressBar from '../../components/common/ProgressBar/ProgressBar.jsx';
import FormModal from '../../components/common/FormModal/FormModal.jsx';
import { useApp } from '../../store/AppContext.jsx';
import { columns } from '../../data/board.js';
import { members } from '../../data/team.js';
import '../../styles/pages/Tasks.css';

const fields = [
  { name: 'title', label: 'Task title' }, { name: 'project', label: 'Project', default: 'General' },
  { name: 'owner', label: 'Owner initials', default: 'JS' }, { name: 'due', label: 'Due', default: 'Oct 15' },
  { name: 'priority', label: 'Priority', options: ['High', 'Medium', 'Low'] },
  { name: 'tone', label: 'Color', options: ['peach', 'sky', 'lilac', 'mint'] }, { name: 'column', label: 'Status', options: columns },
];

export default function Tasks() {
  const { state, add, remove, update } = useApp();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [prio, setPrio] = useState('All');
  const all = state.tasks;
  const items = all.filter((t) => t.title.toLowerCase().includes(q.toLowerCase()) && (prio === 'All' || (t.priority || 'Medium') === prio));
  const move = (t, d) => update('tasks', t.id, { column: Math.min(2, Math.max(0, t.column + d)) });
  const stats = [['Total tasks', all.length], ['In progress', all.filter((t) => t.column === 1).length], ['High priority open', all.filter((t) => t.priority === 'High' && t.column < 2).length], ['Completion', `${Math.round((all.filter((t) => t.column === 2).length / (all.length || 1)) * 100)}%`]];
  return (
    <div>
      <PageHeader eyebrow="Move work forward" title="Tasks" actionLabel="Add task" onAction={() => setOpen(true)}>
        <input className="tool-search" type="search" placeholder="Search tasks" value={q} onChange={(e) => setQ(e.target.value)} />
      </PageHeader>
      <div className="strip">{stats.map(([l, v]) => <div key={l}><strong>{v}</strong><small>{l}</small></div>)}</div>
      <div className="projects-page__filters">{['All', 'High', 'Medium', 'Low'].map((p) => <button key={p} className={`projects-page__filter ${prio === p ? 'is-active' : ''}`} onClick={() => setPrio(p)}>{p === 'All' ? 'All priorities' : `${p} priority`}</button>)}</div>
      <div className="board">
        {columns.map((name, col) => (
          <section key={name} className="board__col">
            <header className="board__head"><h2>{name}</h2><span>{items.filter((t) => t.column === col).length}</span></header>
            <ul className="board__list">
              {items.filter((t) => t.column === col).map((t) => {
                const [d, n] = t.sub || [0, 0], m = members.find((x) => x.initials === t.owner);
                return (
                  <li key={t.id} className={`board__card board__card--${t.tone} tk`}>
                    <div className="tk__top"><span className={`prio prio--${(t.priority || 'Medium').toLowerCase()}`}>{t.priority || 'Medium'}</span><small>{t.project || 'General'}</small></div>
                    <strong>{t.title}</strong>
                    {!!n && <div className="tk__sub"><ProgressBar value={(d / n) * 100} color="var(--ink)" /><small>{d}/{n} subtasks</small></div>}
                    <div className="tk__meta"><span><Icon name="cal" size={13} />{t.due || 'No date'}</span><span><Icon name="mail" size={13} />{t.comments || 0}</span><span title={m ? m.name : t.owner}>{m ? m.name.split(' ')[0] : t.owner}</span></div>
                    <div className="board__foot">
                      <span className="board__owner" style={m ? { background: m.bg } : undefined}>{t.owner}</span>
                      <div className="board__moves">
                        <button onClick={() => move(t, -1)} disabled={col === 0} aria-label="Move back"><Icon name="chevronRight" size={14} className="flip" /></button>
                        <button onClick={() => move(t, 1)} disabled={col === 2} aria-label="Move forward"><Icon name="chevronRight" size={14} /></button>
                        <button onClick={() => remove('tasks', t.id, 'Task deleted')} aria-label="Delete task"><Icon name="trash" size={14} /></button>
                      </div>
                    </div>
                  </li>
                );
              })}
              {!items.some((t) => t.column === col) && <li className="empty">Nothing here.</li>}
            </ul>
          </section>
        ))}
      </div>
      {open && <FormModal title="New task" fields={fields} onClose={() => setOpen(false)} onSubmit={(v) => { add('tasks', { ...v, column: columns.indexOf(v.column), sub: [0, 0], comments: 0 }, 'Task added'); setOpen(false); }} />}
    </div>
  );
}
