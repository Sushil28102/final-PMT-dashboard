import { useState } from 'react';
import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import Card from '../../components/common/Card/Card.jsx';
import Icon from '../../components/common/Icon/Icon.jsx';
import FormModal from '../../components/common/FormModal/FormModal.jsx';
import StatusPill from '../../components/common/StatusPill/StatusPill.jsx';
import { useApp } from '../../store/AppContext.jsx';
import { invoiceStatuses } from '../../data/invoices.js';
import { download } from '../../utils/download.js';
import '../../styles/pages/Invoices.css';

const statuses = invoiceStatuses.slice(1);
const fields = [
  { name: 'client', label: 'Client' }, { name: 'amount', label: 'Amount (USD)', type: 'number' },
  { name: 'due', label: 'Due date', type: 'date' }, { name: 'status', label: 'Status', options: statuses },
];
const money = (n) => `USD ${n.toLocaleString()}`;
const slug = (s) => s.toLowerCase().replace(/\s/g, '-');

export default function Invoices() {
  const { state, add, remove, update, notify } = useApp();
  const [status, setStatus] = useState('All');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(5);
  const [desc, setDesc] = useState(true);
  const all = state.invoices;
  const rows = all.filter((i) => (status === 'All' || i.status === status) && i.client.toLowerCase().includes(q.toLowerCase())).sort((a, b) => (desc ? b.amount - a.amount : a.amount - b.amount));
  const pages = Math.max(1, Math.ceil(rows.length / size)), cur = Math.min(page, pages);
  const view = rows.slice((cur - 1) * size, cur * size);
  const sum = (f) => all.filter(f).reduce((a, i) => a + i.amount, 0);
  const paid = sum((i) => i.status === 'Fully Paid'), billed = sum(() => true);
  const tiles = [['Collected', money(paid), 'green'], ['Outstanding', money(sum((i) => ['Not Paid', 'Partially Paid'].includes(i.status))), 'blue'], ['Overdue', money(sum((i) => i.status === 'Overdue')), 'purple'], ['Collection rate', `${billed ? Math.round((paid / billed) * 100) : 0}%`, 'orange']];
  const pick = (fn) => (v) => { fn(v); setPage(1); };
  return (
    <div>
      <PageHeader eyebrow="Billing" title="Invoices" actionLabel="New invoice" onAction={() => setOpen(true)}>
        <input className="tool-search" type="search" placeholder="Search client" value={q} onChange={(e) => pick(setQ)(e.target.value)} />
        <button className="btn-ghost" onClick={() => download('invoices.csv', ['Invoice,Client,Amount,Due,Status', ...rows.map((r) => `${r.id},${r.client},${r.amount},${r.due},${r.status}`)].join('\n'))}>Export CSV</button>
      </PageHeader>
      <div className="inv-tiles">{tiles.map(([l, v, c]) => <div key={l} className={`inv-tile inv-tile--${c}`}><small>{l}</small><strong>{v}</strong></div>)}</div>
      <div className="invoices-page__filters">
        {invoiceStatuses.map((s) => <button key={s} className={`invoices-page__filter ${status === s ? 'is-active' : ''}`} onClick={() => pick(setStatus)(s)}>{s}{s !== 'All' && <b>{all.filter((i) => i.status === s).length}</b>}</button>)}
      </div>
      <Card>
        <div className="invoices-page__scroll">
          <table className="invoices-page__table">
            <thead><tr><th>Invoice</th><th>Client</th><th><button className="th-sort" onClick={() => setDesc(!desc)}>Amount {desc ? '↓' : '↑'}</button></th><th>Due</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {view.map((r) => (
                <tr key={r.id} className={`row row--${slug(r.status)}`}>
                  <td><strong>{typeof r.id === 'string' ? r.id : `INV-${String(r.id).slice(-4)}`}</strong></td>
                  <td><span className="client"><i>{r.client[0]}</i>{r.client}</span></td><td>{money(r.amount)}</td><td>{r.due}</td>
                  <td><StatusPill status={r.status} /> <select className="invoices-page__select" aria-label="Change status" value={r.status} onChange={(e) => update('invoices', r.id, { status: e.target.value })}>{statuses.map((s) => <option key={s}>{s}</option>)}</select></td>
                  <td className="acts">
                    {r.status !== 'Fully Paid' && <button className="btn-ghost sm" onClick={() => { update('invoices', r.id, { status: 'Fully Paid' }); notify('Marked as paid'); }}>Mark paid</button>}
                    <button className="icon-btn" onClick={() => remove('invoices', r.id, 'Invoice deleted')} aria-label="Delete invoice"><Icon name="trash" size={15} /></button>
                  </td>
                </tr>
              ))}
              {!rows.length && <tr><td colSpan="6" className="invoices-page__empty">No invoices match.</td></tr>}
            </tbody>
            {!!rows.length && <tfoot><tr><td colSpan="2">Total of {rows.length} invoices</td><td colSpan="4"><strong>{money(rows.reduce((a, i) => a + i.amount, 0))}</strong></td></tr></tfoot>}
          </table>
        </div>
        <div className="pager">
          <span>Showing {rows.length ? (cur - 1) * size + 1 : 0}–{Math.min(cur * size, rows.length)} of {rows.length}</span>
          <div>
            <select aria-label="Rows per page" value={size} onChange={(e) => pick(setSize)(Number(e.target.value))}>{[5, 10, 15].map((n) => <option key={n} value={n}>{n} / page</option>)}</select>
            <button disabled={cur === 1} onClick={() => setPage(cur - 1)}>Prev</button>
            {Array.from({ length: pages }, (_, i) => <button key={i} className={cur === i + 1 ? 'is-active' : ''} onClick={() => setPage(i + 1)}>{i + 1}</button>)}
            <button disabled={cur === pages} onClick={() => setPage(cur + 1)}>Next</button>
          </div>
        </div>
      </Card>
      {open && <FormModal title="New invoice" fields={fields} onClose={() => setOpen(false)}
        onSubmit={(v) => { add('invoices', { ...v, id: `INV-${1055 + all.length}`, amount: Number(v.amount), due: new Date(v.due).toLocaleDateString('en-US', { month: 'short', day: '2-digit' }) }, 'Invoice created'); setOpen(false); }} />}
    </div>
  );
}
