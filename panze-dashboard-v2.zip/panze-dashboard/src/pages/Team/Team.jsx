import { useState } from 'react';
import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import Card from '../../components/common/Card/Card.jsx';
import { useApp } from '../../store/AppContext.jsx';
import { members } from '../../data/team.js';
import '../../styles/pages/Team.css';

const R = 22, C = 2 * Math.PI * R;
export default function Team() {
  const { notify } = useApp();
  const [status, setStatus] = useState('All');
  const [sort, setSort] = useState('load');
  const top = [...members].sort((a, b) => b.done - a.done)[0];
  const list = members.filter((m) => status === 'All' || m.status === status).sort((a, b) => (sort === 'name' ? a.name.localeCompare(b.name) : b[sort] - a[sort]));
  const avg = Math.round(members.reduce((a, m) => a + m.load, 0) / members.length);
  return (
    <div>
      <PageHeader eyebrow="People behind the work" title="Team" actionLabel="Invite member" onAction={() => notify('Invite link copied')} />
      <div className="tm-hero">
        <div className="tm-hero__star"><span className="member__avatar" style={{ background: top.bg }}>{top.initials}</span>
          <div><small>Top performer this quarter</small><strong>{top.name}</strong><p>{top.done} tasks shipped · {top.onTime}% on time</p></div></div>
        <div className="tm-hero__stats">
          <div><strong>{members.length}</strong><small>Members</small></div>
          <div><strong>{members.filter((m) => m.status === 'Online').length}</strong><small>Online now</small></div>
          <div><strong>{avg}%</strong><small>Avg workload</small></div>
          <div><strong>{Math.round(members.reduce((a, m) => a + m.onTime, 0) / members.length)}%</strong><small>On-time rate</small></div>
        </div>
      </div>
      <div className="tm-tools">
        <div className="projects-page__filters">{['All', 'Online', 'Away', 'Offline'].map((s) => <button key={s} className={`projects-page__filter ${status === s ? 'is-active' : ''}`} onClick={() => setStatus(s)}>{s}</button>)}</div>
        <label>Sort by <select value={sort} onChange={(e) => setSort(e.target.value)}><option value="load">Workload</option><option value="onTime">On-time rate</option><option value="done">Tasks done</option><option value="name">Name</option></select></label>
      </div>
      <div className="team__grid">
        {list.map((m) => (
          <Card key={m.id} className="member">
            <div className="member__cover" style={{ background: `linear-gradient(135deg, ${m.bg}, var(--surface))` }} />
            <span className="member__avatar" style={{ background: m.bg }}>{m.initials}<i className={`dot dot--${m.status.toLowerCase()}`} title={m.status} /></span>
            <h3>{m.name}</h3>
            <p>{m.role}</p>
            <small className="member__mail">{m.email} · since {m.joined}</small>
            <div className="member__skills">{m.skills.map((s) => <span key={s}>{s}</span>)}</div>
            <div className="member__ring">
              <svg viewBox="0 0 56 56"><circle cx="28" cy="28" r={R} fill="none" stroke="var(--line)" strokeWidth="6" /><circle cx="28" cy="28" r={R} fill="none" stroke={m.load > 90 ? 'var(--red)' : m.load > 70 ? 'var(--orange)' : 'var(--green)'} strokeWidth="6" strokeLinecap="round" strokeDasharray={`${(C * m.load) / 100} ${C}`} transform="rotate(-90 28 28)" /></svg>
              <div><strong>{m.load}% capacity</strong><small>{m.load > 90 ? 'Overloaded' : m.load > 70 ? 'Busy' : 'Has room'}</small></div>
            </div>
            <div className="member__stats">
              <div><strong>{m.tasks}</strong><span>Open tasks</span></div><div><strong>{m.projects}</strong><span>Projects</span></div><div><strong>{m.onTime}%</strong><span>On time</span></div>
            </div>
            <div className="member__actions"><button className="btn-ghost" onClick={() => notify(`Message sent to ${m.name.split(' ')[0]}`)}>Message</button><button className="btn-primary" onClick={() => notify(`Task assigned to ${m.name.split(' ')[0]}`)}>Assign task</button></div>
          </Card>
        ))}
      </div>
    </div>
  );
}
