import { useEffect, useState } from 'react';
import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import Card from '../../components/common/Card/Card.jsx';
import { useApp } from '../../store/AppContext.jsx';
import { download } from '../../utils/download.js';
import '../../styles/pages/Settings.css';

const accents = ['#5b4bdb', '#2f80ed', '#27ae60', '#ee7a3f', '#d6336c'];
const events = [['Task assigned', 'email', 'push', 'slack'], ['Meeting reminder', 'email', 'push', 'slack'], ['Invoice paid or overdue', 'email', 'push', 'slack']];
const keys = [['Ctrl K', 'Open search and commands'], ['Esc', 'Close dialogs'], ['↑ ↓ Enter', 'Move and select in search']];
const log = ['Signed in from Chrome on Windows', 'Exported invoices as CSV', 'Changed workspace currency to USD', 'Invited Mia Chen to the team'];

export default function Settings() {
  const { state, toggleTheme, reset, notify } = useApp();
  const [profile, setProfile] = useState({ name: 'John Smith', email: 'john.smith@panze.com', role: 'Project manager' });
  const [accent, setAccent] = useState(() => localStorage.getItem('panze-accent') || accents[0]);
  const [ws, setWs] = useState({ currency: 'USD', zone: 'Asia/Kolkata', week: 'Monday' });
  const [matrix, setMatrix] = useState({ '0-email': true, '0-push': true, '1-email': true, '1-slack': true, '2-push': true });
  const [saved, setSaved] = useState(false);
  useEffect(() => { document.documentElement.style.setProperty('--accent', accent); document.documentElement.style.setProperty('--accent-soft', `${accent}26`); localStorage.setItem('panze-accent', accent); }, [accent]);
  const counts = [['Tasks', state.tasks.length], ['Projects', state.projects.length], ['Invoices', state.invoices.length], ['Meetings', state.meetings.length]];
  const kb = (new Blob([JSON.stringify(state)]).size / 1024).toFixed(1);
  const on = (e) => { setSaved(false); setProfile({ ...profile, [e.target.name]: e.target.value }); };
  return (
    <div>
      <PageHeader eyebrow="Make it yours" title="Settings" />
      <div className="settings__grid">
        <div className="settings__col">
          <Card title="Profile">
            <form className="settings__form" onSubmit={(e) => { e.preventDefault(); setSaved(true); notify('Profile saved'); }}>
              <div className="set-id"><span className="topbar__avatar" style={{ background: accent, color: '#fff' }}>{profile.name.split(' ').map((w) => w[0]).join('').slice(0, 2)}</span><div><strong>{profile.name}</strong><small>{profile.role} · Member since Jan 2023</small></div></div>
              <label>Full name<input name="name" value={profile.name} onChange={on} /></label>
              <label>Email<input name="email" type="email" value={profile.email} onChange={on} /></label>
              <label>Role<input name="role" value={profile.role} onChange={on} /></label>
              <div className="settings__actions"><button type="submit" className="settings__save">Save changes</button>{saved && <span className="settings__saved">Saved</span>}</div>
            </form>
          </Card>
          <Card title="Notification channels">
            <table className="set-matrix"><thead><tr><th>Event</th><th>Email</th><th>Push</th><th>Slack</th></tr></thead>
              <tbody>{events.map(([l, ...ch], r) => <tr key={l}><td>{l}</td>{ch.map((c) => <td key={c}><input type="checkbox" aria-label={`${l} by ${c}`} checked={!!matrix[`${r}-${c}`]} onChange={() => setMatrix({ ...matrix, [`${r}-${c}`]: !matrix[`${r}-${c}`] })} /></td>)}</tr>)}</tbody></table>
          </Card>
          <Card title="Keyboard shortcuts"><ul className="set-keys">{keys.map(([k, d]) => <li key={k}><kbd>{k}</kbd><span>{d}</span></li>)}</ul></Card>
        </div>
        <div className="settings__col">
          <Card title="Appearance">
            <ul className="settings__toggles"><li><span>Dark mode</span><button role="switch" aria-checked={state.theme === 'dark'} className={`switch ${state.theme === 'dark' ? 'is-on' : ''}`} onClick={toggleTheme}><i /></button></li></ul>
            <p className="set-label">Accent color</p>
            <div className="set-swatches">{accents.map((c) => <button key={c} className={accent === c ? 'is-on' : ''} style={{ background: c }} onClick={() => setAccent(c)} aria-label={`Use accent ${c}`} />)}</div>
          </Card>
          <Card title="Workspace">
            <div className="settings__form">
              <label>Currency<select value={ws.currency} onChange={(e) => setWs({ ...ws, currency: e.target.value })}>{['USD', 'EUR', 'INR', 'GBP'].map((o) => <option key={o}>{o}</option>)}</select></label>
              <label>Time zone<select value={ws.zone} onChange={(e) => setWs({ ...ws, zone: e.target.value })}>{['Asia/Kolkata', 'Europe/London', 'America/New_York'].map((o) => <option key={o}>{o}</option>)}</select></label>
              <label>Week starts on<select value={ws.week} onChange={(e) => setWs({ ...ws, week: e.target.value })}>{['Monday', 'Sunday'].map((o) => <option key={o}>{o}</option>)}</select></label>
            </div>
          </Card>
          <Card title="Data and storage">
            <div className="set-counts">{counts.map(([l, v]) => <div key={l}><strong>{v}</strong><small>{l}</small></div>)}</div>
            <p className="set-note">Stored in this browser · {kb} KB used</p>
            <div className="settings__actions"><button className="btn-ghost" onClick={() => download('panze-backup.json', JSON.stringify(state, null, 2), 'application/json')}>Download backup</button><button className="btn-ghost" onClick={reset}>Restore demo data</button></div>
          </Card>
          <Card title="Recent activity"><ul className="set-log">{log.map((t) => <li key={t}>{t}</li>)}</ul></Card>
        </div>
      </div>
    </div>
  );
}
