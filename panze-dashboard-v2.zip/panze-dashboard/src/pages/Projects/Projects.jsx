import { useState } from 'react';
import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import Card from '../../components/common/Card/Card.jsx';
import Icon from '../../components/common/Icon/Icon.jsx';
import ProgressBar from '../../components/common/ProgressBar/ProgressBar.jsx';
import StatusPill from '../../components/common/StatusPill/StatusPill.jsx';
import FormModal from '../../components/common/FormModal/FormModal.jsx';
import { useApp } from '../../store/AppContext.jsx';
import { members } from '../../data/team.js';
import '../../styles/pages/Projects.css';

const filters = ['All', 'In Progress', 'Completed', 'Not Started'];
const fields = [
  { name: 'name', label: 'Project name' }, { name: 'client', label: 'Client' },
  { name: 'due', label: 'Due date', type: 'date' }, { name: 'tone', label: 'Color', options: ['peach', 'lilac', 'mint', 'sky'] },
];
const statusOf = (p) => (p >= 100 ? 'Completed' : p <= 0 ? 'Not Started' : 'In Progress');
const who = (i) => members.find((m) => m.initials === i) || { name: i, bg: '#eee', initials: i };
const Av = ({ i }) => <span className="av" style={{ background: who(i).bg }} title={who(i).name}>{who(i).initials}</span>;

export default function Projects() {
  const { state, add, remove, update } = useApp();
  const [filter, setFilter] = useState('All');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const all = state.projects;
  const list = all.filter((p) => (filter === 'All' || p.status === filter) && p.name.toLowerCase().includes(q.toLowerCase()));
  const budget = all.reduce((a, p) => a + (p.budget || 0), 0), spent = all.reduce((a, p) => a + (p.spent || 0), 0);
  const stats = [['Total projects', all.length], ['In progress', all.filter((p) => p.status === 'In Progress').length], ['Completed', all.filter((p) => p.status === 'Completed').length], ['Budget used', `${budget ? Math.round((spent / budget) * 100) : 0}%`]];
  return (
    <div>
      <PageHeader eyebrow="Everything in flight" title="Projects" actionLabel="New project" onAction={() => setOpen(true)}>
        <input className="tool-search" type="search" placeholder="Search projects" value={q} onChange={(e) => setQ(e.target.value)} />
      </PageHeader>
      <div className="strip">{stats.map(([l, v]) => <div key={l}><strong>{v}</strong><small>{l}</small></div>)}</div>
      <div className="projects-page__filters">
        {filters.map((f) => <button key={f} className={`projects-page__filter ${filter === f ? 'is-active' : ''}`} onClick={() => setFilter(f)}>{f}</button>)}
      </div>
      <div className="projects-page__grid">
        {list.map((p) => {
          const done = p.status === 'Completed', over = p.budget && p.spent / p.budget > 0.9 && !done;
          return (
            <Card key={p.id} className={`project-card project-card--${p.tone}`}>
              <div className="project-card__top">
                <StatusPill status={p.status} /><span><Icon name="cal" size={13} /> Due {p.due}</span>
                <button className="icon-btn" onClick={() => remove('projects', p.id, 'Project deleted')} aria-label="Delete project"><Icon name="trash" size={15} /></button>
              </div>
              <h3>{p.name}</h3>
              <p>{p.client}</p>
              <dl className="pc__who">
                <div><dt>Created by</dt><dd><Av i={p.createdBy || 'JS'} />{who(p.createdBy || 'JS').name.split(' ')[0]}<small>{p.created}</small></dd></div>
                <div><dt>{done ? 'Completed by' : 'Owner'}</dt><dd><Av i={done ? p.completedBy || p.owner : p.owner || 'JS'} />{who(done ? p.completedBy || p.owner : p.owner || 'JS').name.split(' ')[0]}{done && <small>{p.completed}</small>}</dd></div>
              </dl>
              <div className="pc__row">
                <span className="stack">{(p.team || []).map((t) => <Av key={t} i={t} />)}</span>
                <span className="pc__chip"><Icon name="check" size={13} />{(p.tasks || [0, 0])[0]}/{(p.tasks || [0, 0])[1]} tasks</span>
              </div>
              {!!p.budget && <div className={`pc__budget ${over ? 'is-over' : ''}`}><span>Budget ${p.spent.toLocaleString()} / ${p.budget.toLocaleString()}</span><ProgressBar value={Math.min(100, (p.spent / p.budget) * 100)} color={over ? 'var(--red)' : 'var(--green)'} /></div>}
              <div className="project-card__progress"><ProgressBar value={p.progress} color="var(--ink)" /><span>{p.progress}%</span></div>
              <input className="project-card__range" type="range" min="0" max="100" step="5" value={p.progress} aria-label="Progress"
                onChange={(e) => { const v = Number(e.target.value); update('projects', p.id, { progress: v, status: statusOf(v), ...(v >= 100 ? { completedBy: p.owner || 'JS', completed: 'Today' } : {}) }); }} />
            </Card>
          );
        })}
        {!list.length && <p className="empty">No projects match.</p>}
      </div>
      {open && <FormModal title="New project" fields={fields} onClose={() => setOpen(false)}
        onSubmit={(v) => { add('projects', { ...v, progress: 0, status: 'Not Started', createdBy: 'JS', owner: 'JS', team: ['JS'], tasks: [0, 0], budget: 0, spent: 0, created: 'Today', due: new Date(v.due).toLocaleDateString('en-US', { month: 'short', day: '2-digit' }) }, 'Project created'); setOpen(false); }} />}
    </div>
  );
}
