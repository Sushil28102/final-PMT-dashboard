import { useState } from 'react';
import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import Card from '../../components/common/Card/Card.jsx';
import Icon from '../../components/common/Icon/Icon.jsx';
import FormModal from '../../components/common/FormModal/FormModal.jsx';
import { useApp } from '../../store/AppContext.jsx';
import '../../styles/pages/Meetings.css';

const days = ['Today', 'Tomorrow', 'This Week'];
const fields = [
  { name: 'title', label: 'Meeting title' }, { name: 'time', label: 'Time', default: '10:00 AM' },
  { name: 'day', label: 'When', options: days }, { name: 'where', label: 'Platform', options: ['Meet', 'Zoom'] },
  { name: 'duration', label: 'Duration (min)', type: 'number', default: '30' }, { name: 'people', label: 'Attendees', default: 'Everyone' },
  { name: 'agenda', label: 'Agenda', default: 'Quick sync' },
];
const hrs = (m) => `${(m / 60).toFixed(1).replace('.0', '')}h`;

export default function Meetings() {
  const { state, add, remove, notify } = useApp();
  const [open, setOpen] = useState(false);
  const all = state.meetings, today = all.filter((m) => m.day === 'Today');
  const mins = (l) => l.reduce((a, m) => a + Number(m.duration || 30), 0);
  const next = today[0];
  const stats = [['Meetings today', today.length], ['Time in meetings today', hrs(mins(today))], ['This week', `${all.length} · ${hrs(mins(all))}`], ['Up next', next ? `${next.title}, ${next.time}` : 'Nothing today']];
  return (
    <div>
      <PageHeader eyebrow="Your calendar" title="Meetings" actionLabel="Schedule meeting" onAction={() => setOpen(true)} />
      <div className="strip">{stats.map(([l, v]) => <div key={l}><strong>{v}</strong><small>{l}</small></div>)}</div>
      <div className="meetings-page__groups">
        {days.map((day) => {
          const items = all.filter((m) => m.day === day);
          return (
            <Card key={day} title={`${day} · ${items.length} ${items.length === 1 ? 'meeting' : 'meetings'} · ${hrs(mins(items))}`}>
              <ul className="meetings-page__list">
                {items.map((m, idx) => (
                  <li key={m.id} className={`meetings-page__row mt mt--${m.where.toLowerCase()}`}>
                    <span className="meetings-page__time"><Icon name="clock" size={16} /><span>{m.time}<small>{m.duration || 30} min</small></span></span>
                    <div className="meetings-page__info"><strong>{m.title}{day === 'Today' && idx === 0 && <em className="mt__next">Up next</em>}</strong>
                      <small>{m.agenda || 'No agenda'}</small><small>Organizer {m.organizer || 'JS'} · Attendees {m.people}</small></div>
                    <span className="meetings-page__where">{m.where}</span>
                    <div className="meetings-page__btns">
                      <button className="meetings-page__join" onClick={() => notify(`Joining ${m.title} on ${m.where}`)}>Join</button>
                      <button className="icon-btn" onClick={() => remove('meetings', m.id, 'Meeting cancelled')} aria-label="Cancel meeting"><Icon name="trash" size={15} /></button>
                    </div>
                  </li>
                ))}
                {!items.length && <li className="empty">Nothing scheduled.</li>}
              </ul>
            </Card>
          );
        })}
      </div>
      {open && <FormModal title="Schedule meeting" fields={fields} onClose={() => setOpen(false)} onSubmit={(v) => { add('meetings', { ...v, organizer: 'JS' }, 'Meeting scheduled'); setOpen(false); }} />}
    </div>
  );
}
