import { Link } from 'react-router-dom';
import Card from '../../components/common/Card/Card.jsx';
import '../../styles/pages/NotFound.css';

export default function NotFound() {
  return (
    <Card className="not-found">
      <h1>404</h1>
      <p>This page doesn't exist.</p>
      <Link to="/">Back to dashboard</Link>
    </Card>
  );
}
