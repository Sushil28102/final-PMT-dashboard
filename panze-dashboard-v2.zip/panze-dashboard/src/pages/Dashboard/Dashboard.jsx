import PageHeader from '../../components/common/PageHeader/PageHeader.jsx';
import KpiStrip from '../../components/dashboard/KpiStrip/KpiStrip.jsx';
import WaveChart from '../../components/dashboard/WaveChart/WaveChart.jsx';
import Burndown from '../../components/dashboard/Burndown/Burndown.jsx';
import Workload from '../../components/dashboard/Workload/Workload.jsx';
import TaskList from '../../components/dashboard/TaskList/TaskList.jsx';
import ProjectsOverview from '../../components/dashboard/ProjectsOverview/ProjectsOverview.jsx';
import Meetings from '../../components/dashboard/Meetings/Meetings.jsx';
import InvoiceOverview from '../../components/dashboard/InvoiceOverview/InvoiceOverview.jsx';
import OpenTickets from '../../components/dashboard/OpenTickets/OpenTickets.jsx';
import '../../styles/pages/Dashboard.css';

const greet = () => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'; };

export default function Dashboard() {
  return (
    <div className="dashboard">
      <PageHeader eyebrow={`${greet()}, John`} title="Project Dashboard" />
      <KpiStrip />
      <div className="dashboard__grid">
        <div className="area-wave"><WaveChart /></div>
        <div className="area-burn"><Burndown /></div>
        <div className="area-tasks"><TaskList /></div>
        <div className="area-load"><Workload /></div>
        <div className="area-invoice"><InvoiceOverview /></div>
        <div className="area-projects"><ProjectsOverview /></div>
        <div className="area-meetings"><Meetings /></div>
        <div className="area-tickets"><OpenTickets /></div>
      </div>
    </div>
  );
}
