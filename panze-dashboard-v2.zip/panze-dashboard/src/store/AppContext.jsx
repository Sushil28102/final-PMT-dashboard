import { createContext, useContext, useEffect, useReducer, useState, useCallback } from 'react';
import { boardTasks } from '../data/board.js';
import { projects } from '../data/projects.js';
import { invoices } from '../data/invoices.js';
import { schedule } from '../data/schedule.js';
import Toast from '../components/common/Toast/Toast.jsx';

const KEY = 'panze-state-v3';
const initial = {
  theme: 'light',
  tasks: boardTasks,
  projects,
  invoices: invoices.map((i) => ({ ...i, amount: Number(i.amount.replace(/\D/g, '')) })),
  meetings: schedule.flatMap((g) => g.items.map((m) => ({ ...m, day: g.day }))),
};

function reducer(s, a) {
  switch (a.type) {
    case 'add': return { ...s, [a.key]: [a.item, ...s[a.key]] };
    case 'remove': return { ...s, [a.key]: s[a.key].filter((i) => i.id !== a.id) };
    case 'update': return { ...s, [a.key]: s[a.key].map((i) => (i.id === a.id ? { ...i, ...a.patch } : i)) };
    case 'theme': return { ...s, theme: s.theme === 'dark' ? 'light' : 'dark' };
    case 'reset': return initial;
    default: return s;
  }
}

const load = () => {
  try { return { ...initial, ...JSON.parse(localStorage.getItem(KEY)) }; } catch { return initial; }
};

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, load);
  const [toast, setToast] = useState('');

  useEffect(() => { localStorage.setItem(KEY, JSON.stringify(state)); }, [state]);
  useEffect(() => { document.documentElement.dataset.theme = state.theme; }, [state.theme]);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(''), 2200); return () => clearTimeout(t); }, [toast]);

  const api = {
    state,
    notify: setToast,
    add: useCallback((key, item, msg) => { dispatch({ type: 'add', key, item: { id: Date.now(), ...item } }); if (msg) setToast(msg); }, []),
    remove: useCallback((key, id, msg) => { dispatch({ type: 'remove', key, id }); if (msg) setToast(msg); }, []),
    update: useCallback((key, id, patch) => dispatch({ type: 'update', key, id, patch }), []),
    toggleTheme: () => dispatch({ type: 'theme' }),
    reset: () => { dispatch({ type: 'reset' }); setToast('Demo data restored'); },
  };
  return <Ctx.Provider value={api}>{children}<Toast message={toast} /></Ctx.Provider>;
}
