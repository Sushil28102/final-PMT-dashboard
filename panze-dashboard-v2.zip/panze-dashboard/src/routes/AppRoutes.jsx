import { Routes, Route } from 'react-router-dom';
import MainLayout from '../layouts/MainLayout/MainLayout.jsx';
import Dashboard from '../pages/Dashboard/Dashboard.jsx';
import Projects from '../pages/Projects/Projects.jsx';
import Team from '../pages/Team/Team.jsx';
import Tasks from '../pages/Tasks/Tasks.jsx';
import Meetings from '../pages/Meetings/Meetings.jsx';
import Invoices from '../pages/Invoices/Invoices.jsx';
import Reports from '../pages/Reports/Reports.jsx';
import Settings from '../pages/Settings/Settings.jsx';
import NotFound from '../pages/NotFound/NotFound.jsx';

export default function AppRoutes() {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="projects" element={<Projects />} />
        <Route path="team" element={<Team />} />
        <Route path="tasks" element={<Tasks />} />
        <Route path="meetings" element={<Meetings />} />
        <Route path="invoices" element={<Invoices />} />
        <Route path="reports" element={<Reports />} />
        <Route path="settings" element={<Settings />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
