import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '../../components/layout/Sidebar/Sidebar.jsx';
import Topbar from '../../components/layout/Topbar/Topbar.jsx';
import CommandPalette from '../../components/common/CommandPalette/CommandPalette.jsx';
import Leaves from '../../components/common/Leaves/Leaves.jsx';
import '../../styles/layouts/MainLayout.css';

export default function MainLayout() {
  const [expanded, setExpanded] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <>
      <Leaves />
      <CommandPalette />
      <div className="shell">
        <Sidebar expanded={expanded} onToggle={() => setExpanded((v) => !v)} mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />
        <main className="shell__main">
          <Topbar onMenu={() => setMobileOpen(true)} />
          <Outlet />
        </main>
      </div>
    </>
  );
}
