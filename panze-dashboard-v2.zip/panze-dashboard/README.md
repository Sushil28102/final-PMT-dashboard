# Panze Dashboard

React + Vite + React Router, plain CSS. One CSS file per component, layout and page.

    npm install
    npm run dev
    npm run build

## Structure

    src/
      main.jsx            entry, imports styles/main.css
      App.jsx
      routes/             route table
      layouts/            MainLayout
      components/
        common/           Icon, Leaves, Card, PageHeader, ProgressBar, StatusPill
        layout/           Sidebar, Topbar
        dashboard/        dashboard widgets
      pages/              Dashboard, Projects, Team, Tasks, Meetings, Invoices, Reports, Settings, NotFound
      data/               mock data
      styles/
        main.css          global styles and design tokens
        layouts/
        components/{common,layout,dashboard}/
        pages/
